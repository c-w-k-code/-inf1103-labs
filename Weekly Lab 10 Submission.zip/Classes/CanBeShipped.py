from abc import ABC, abstractmethod


class CanBeShipped(ABC):
    """Contract for anything that can be shipped. No attributes, no implementation."""

    @abstractmethod
    def calculate_shipping_cost(self) -> float:
        """Return the shipping cost for this object."""
        pass